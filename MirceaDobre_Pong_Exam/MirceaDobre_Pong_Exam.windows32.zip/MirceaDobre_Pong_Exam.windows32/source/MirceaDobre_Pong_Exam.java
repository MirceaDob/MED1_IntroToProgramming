import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class MirceaDobre_Pong_Exam extends PApplet {

 // sound library with sounds for different game events ; the names are self explanatory
SoundFile ballHit;
SoundFile flowerHit;
SoundFile flowerShow;
SoundFile ballMiss;

BallClass[] balls;
Court court;
Flower flower;

boolean Start = false; // keeps track of Play/Pause
boolean streak = false; // keeps track of hitting balls in a row, without missing

float balX = random(width); // x coordinate for ball
float balY = random(height); // y coordinate for ball
float pad1X; // x coordinate for the paddle
float pad1Y; // y coordinate for the paddle
float pad1W = 30; // paddle width
float pad1H = 200; // paddle height

int scor = 0; // score
int edge = 10; // size of the window edge
int ft = 0; // when it gets to 10, the user can generate a flower

int cul = color(random(255), random(255), random(255)); // random color for balls and background

public void setup() {

background(0xff080808);
noStroke();

pad1X = width-pad1W; // placing the pad on the right hand side of the window
textSize(60);
balls = new BallClass[3]; // array for generating 3 balls
balls[0] = new BallClass(random(20,width/5), random(20,height/5));
balls[1] = new BallClass(random(20,width/5), random(20,height/5));
balls[2] = new BallClass(random(20,width/5), random(20,height/5));
court = new Court();

flower = new Flower(random(20, width/5), random(20, height-10)); // generating a flower object

// assigning sound files for the game sounds
ballHit = new SoundFile(this, "Robot_blip.wav");
flowerHit = new SoundFile(this, "Robot_blip_2.wav");
flowerShow = new SoundFile(this, "A-Tone.wav");
ballMiss = new SoundFile(this, "Short_Beep.wav");
}

public void draw() {
  
  court.makeCourt();
  
  if (mouseY <= height) {
    pad1Y = mouseY - pad1H / 2; // the cursor is set in the middle of the pad
  }
  
  for (int i = 0; i < balls.length; i++){ // generates the balls
    BallClass ball = balls[i];
        
    ball.makeBall();
    ball.wallCollision();
    ball.scoreBall();
  }
  if (streak == true) {
    flower.display();
    flower.wallCollision();
    flower.scoreFlower();
  }
}
  
public void mousePressed() {
  if (mouseButton == LEFT) { // click left mouse button to start / pause the game 
   Start = !Start;
  }
  else if (mouseButton == RIGHT) { // right mouse button changes colors
    cul = color(random(255), random(255), random(255));
    background(cul * -1);
    }
}
class BallClass {

float balX = random(20,width);
float balY = random(20,height);
float balH = 50; // ball size
float spdX = random(3,5); // random numbers to increase ball movement speed
float spdY = random(3,5); //

BallClass(float balX, float balY) { // constructor
  this.balX = balX;
  this.balY = balY;
}

public void makeBall() { // draw a ball
  fill(cul);
  ellipse(balX, balY, balH, balH);
}

public void wallCollision() { // collision between the ball and the walls
 if (Start) {
    balX = balX + spdX;
    balY = balY + spdY;
  
  if ((balY <= balH / 2) || (balY >= height - balH / 2)) { // ball bounces off the top and bottom walls
    spdY = -spdY;
    balY = balY + spdY;
  }
  if (balX <= balH / 2) { // ball bounces off the left wall
    spdX = -spdX;
    balX = balX + spdX;
  }
}
}

public void scoreBall() {
  if ((balX > width - balH / 2 - pad1W) && (balY > mouseY - pad1H / 2) && (balY < mouseY + pad1H / 2)) { // if the ball hits the pad it bounces off and the score increases by 1
      ballHit.play();
      spdX = spdX * 1.1f;
      spdX = -spdX;
      balX = balX + spdX;
      scor += 1;
      ft += 1;
      if (ft == 10) {
        flowerShow.play();
        streak = true;
        ft = 0;
    }
  }
  
  if (balX > width) { // if the ball hits the right wall instead of the pad the score decreases and the ball respawns
    ballMiss.play();
    balX = random(width);
    balY = random(height); 
    spdX = random(3, 5);
    spdY = random(3, 5);
    scor = scor-1;
    ft = 0;
  }
}
}
class Court {

Court() { // constructor
}  

public void makeCourt() {  
  background(cul * -1);
  fill(cul);
  // putting text on the screen - playing instructions and score
  textSize(20);
  text("Left click to Play/Pause", width - 1300, height - 500);
  text("Right click to change colors according to your preferences", width - 1300, height - 400);
  text("Hit the balls 10 times in a row to get a flower", width - 1300, height - 300);
  text("Each time you hit the flower you get 10 points", width - 1300, height - 200);
  text("Please keep the mouse cursor inside the game window", width - 1300, height - 100);
  textSize(50);
  text("Score: ", width - 500, 100);
  text(scor, width - 200, 100);
  textSize(25);
  text("Streak: ", width - 500, 200);
  text(ft, width - 200, 200);
  fill(0xff2DC940);
  // making borders for the top, bottom and lefthand side walls
  rect(0, 0, width, edge);
  rect(0, height - edge, width, edge); 
  rect(0, 0, edge, height);
  fill(0xffFA340D);
  // making border for the right hand side wall
  rect(width - edge, 0, edge, height);
  fill(cul);
  rect(pad1X, pad1Y, pad1W, pad1H, 10);
}
}
class Flower {
  
 float r = 20;       // radius of the flower petal
 int n_petals = 9;  // number of petals 
 float x = random(20,width);       // x-position of the center of the flower
 float y = random(20,height);       // y-position of the center of the flower
 float spdx = random(3,5);
 float spdy = random(3,5);
 int cul1 = color(255, 0, 0); // 
 int cul2 = color(0, 255, 255); //
 
Flower(float x, float y) { // constructor
  this.x = x;
  this.y = y;
}

public void display () {
  
  float petX; // petals coordinates
  float petY;
  
  fill(cul2);
  for (float i = 0; i < PI*2; i += 2*PI/n_petals) {
  petX = x + r*cos(i);
  petY = y + r*sin(i);
  ellipse(petX,petY,r,r); // draw petals
  }
  fill(cul1);
  ellipse(x,y,r*1.2f,r*1.2f); // draw center
}

public void wallCollision() { // collision between the flower and the walls
 if (Start) {
    x += spdx;
    y += spdy;
  
  if ((y <= r*1.5f) || (y >= height - r*1.5f)) { // the flower bounces off the top and bottom walls
    spdy = -spdy;
    y += spdy;
  }
  if (x <= r*1.5f) { // the flower bounces off the left wall
    spdx = -spdx;
    x += spdx;
  }
}
}

public void scoreFlower() {
  if ((x > width - r*1.5f - pad1W) && (y > mouseY - pad1H / 2) && (y < mouseY + pad1H / 2)) { // if the flower hits the pad it bounces off and the score increases by 10
      flowerHit.play();
      spdx = spdx * 1.1f;
      spdx = -spdx;
      x += spdx;
      scor += 10;
  }

  if (x > width) { // if the flower hits the right wall instead of the pad it resets the STREAK COUNTER 
    ballMiss.play();
    streak = false;
    x = random(20,width);
    y = random(20,height);
    spdx = random(3,5);
    spdy = random(3,5);
  }
}
}
  public void settings() { 
size(1600,1000); 
smooth(4); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "MirceaDobre_Pong_Exam" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
